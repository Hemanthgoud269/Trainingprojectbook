package com.cg.bms.dao;


import java.util.List;

import com.cg.bms.bean.BookBean;
import com.cg.bms.exceptions.BookException;

public interface IBookDao {
int addBookDetails(BookBean bean) throws BookException;

int editBookDetails(BookBean bean) throws BookException;
public List<BookBean> viewBookDetails() throws BookException;
public int deleteBook(int Id) throws BookException;
public List<BookBean> searchBook(int Id) throws BookException;
public boolean adminLogin(BookBean bean) throws BookException;
public boolean addadmin(BookBean bean) throws BookException;
public boolean adminEmail(String email) throws BookException;

}
