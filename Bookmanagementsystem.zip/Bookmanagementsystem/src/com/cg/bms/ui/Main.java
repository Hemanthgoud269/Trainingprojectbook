package com.cg.bms.ui;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.bms.bean.BookBean;

import com.cg.bms.exceptions.BookException;
import com.cg.bms.service.BookService;

public class Main {

	@SuppressWarnings("resource")
	public static void main(String[] args) throws Exception {
		Scanner scanner = new Scanner(System.in);
		BookBean bean = new BookBean();
		BookService service = new BookService();
try {
		boolean adminloginflag = false;
		boolean emailcheckflag = false;
		boolean emailflag2 = false;
		boolean mainflag=true;
		do {
			try {
				System.out.println("Enter the Email");
				String admin_email = scanner.next();

				service.checkEmailPattern(admin_email);
				bean.setAdmin_email(admin_email);
				emailcheckflag = true;
				emailflag2 = service.adminEmail(admin_email);

			} catch (BookException e) {
				System.out.println(e);
			}
		} while (!emailcheckflag || !emailflag2);

		boolean passwordcheckflag = false;
		do {
			do {

				System.out.println("Enter the Password");
				try {
					String adminpassword = scanner.next();

					service.checkPasswordPattern(adminpassword);
					bean.setAdmin_password(adminpassword);
					passwordcheckflag = true;
				} catch (BookException e) {
					System.out.println(e);
				}
			} while (!passwordcheckflag);

			adminloginflag = service.adminLogin(bean);
		} while (!adminloginflag);
		while (true) {

			System.out.println("Enter your choice");
			System.out.println("1) Add new book ");
			System.out.println("2) view all books ");
			System.out.println("3) Edit existing book");
			System.out.println("4) delete book ");
			System.out.println("5) exit ");
			try {
				
				int choice = scanner.nextInt();

				switch (choice) {
				case 1:
					try {
						scanner = new Scanner(System.in);
						String title = null;
						boolean titleflag = false;
						do {
							System.out.println("Enter the name of the book");
							try {
								title = scanner.nextLine();
								service.validateTitle(title);
								titleflag = true;
								bean.setBook_title(title);
								break;
							} catch (BookException e) {
								System.err.println(e.getMessage());
							}

						} while (!titleflag);
					
						String author = null;
						boolean authorflag = false;
						do {
							System.out.println("Enter author of the book");
							try {
								author = scanner.nextLine();
								service.validateAuthor(author);
								authorflag = true;
								bean.setAuthor(author);
								break;
							} catch (BookException e) {
								System.err.println(e.getMessage());
							}
						} while (!authorflag);
						
						String category = null;
						boolean categoryflag = false;
						do {
							System.out.println("Enter the category of the book");
							try {
								category = scanner.nextLine();
								service.vaildateCategory(category);
								categoryflag = true;
								bean.setCategory(category);

								break;
							} catch (BookException e) {
								System.err.println(e.getMessage());
							}
						} while (!categoryflag);

						float price;
						boolean priceflag = false;

						do {
							System.out.println("what is the price of the book");
							try {
								scanner = new Scanner(System.in);
								price = scanner.nextFloat();

								service.validatePrice(price);
								priceflag = true;

								bean.setPrice(price);
								break;
							}

							catch (InputMismatchException e) {
								System.err.println("Enter only digits");
							} catch (BookException e) {
								System.out.println(e.getMessage());
							}
						} while (!priceflag);

						scanner = new Scanner(System.in);
						String description = null;
						boolean descriptionflag = false;
						do {
							System.out.println("Enter the description");
							try {
								description = scanner.nextLine();
								service.validateDescription(description);
								descriptionflag = true;
								bean.setDescription(description);
								break;

							} catch (BookException e) {
								System.err.println(e.getMessage());
							}

						} while (!descriptionflag);

						boolean isbnflag = false;
						long isbn;
						do {
							System.out.println("Enter the ISBN");
							try {
								scanner = new Scanner(System.in);
								isbn = scanner.nextLong();
								service.validateISBN(isbn);
								isbnflag = true;

								bean.setIsbn(isbn);
								break;
							} catch (InputMismatchException e) {
								System.out.println("Enter digits only");

							} catch (BookException e) {
								System.err.println(e.getMessage());
							}
						} while (!isbnflag);
						
						String publishDate = null;
						boolean publishdateflag = false;
						do {
							System.out.println("Enter the publish date");
							try {
								publishDate = scanner.next();
								service.validatePublishdate(publishDate);
								publishdateflag = true;
								bean.setPublish_date(publishDate);
							} catch (BookException e) {
								System.err.println(e.getMessage());
							}
						} while (!publishdateflag);
						int bookid = service.addBookDetails(bean);
						System.out.println("book is succesfully added with id=" + bookid);
						System.out.println("Do you wish to continue 1)yes \n 2)no");
						int choice1 = scanner.nextInt();
						while (choice1 == 2) {

							System.out.println("*** Thank you *** ");
							System.exit(0);
							break;
						}
					} catch (InputMismatchException e) {
						System.out.println(e);
					}
					do {System.out.println("Do you wish to continue 1)yes \n 2)no");
					try {
					scanner=new Scanner(System.in);
					int choice2 = scanner.nextInt();
					if(choice2 == 2) {

			System.out.println("*** Thank you *** ");
						System.exit(0);
						break;
					}
					else if(choice2==1) {
						mainflag=false;
					}
					else {
						throw new BookException("Enter option 1 or 2");
					}
						
					
					}catch(InputMismatchException e) {
						System.out.println("Enter numbers only");
						
					}
					catch(BookException e) {
						System.out.println(e.getMessage());
					}
					}while(mainflag);
					break;

				case 2:
					BookService service1 = new BookService();
					List<BookBean> bookdetails = new ArrayList<BookBean>();

					bookdetails = service1.viewBookDetails();

					if (bookdetails != null) {

						Iterator<BookBean> i = bookdetails.iterator();

						while (i.hasNext()) {
							System.out.println(i.next());
						}
						
						}
					 else {

						System.out.println("\n ******No book details are inserted till now******\n");
					}
					do {System.out.println("Do you wish to continue 1)yes \n 2)no");
						try {
						scanner=new Scanner(System.in);
						int choice2 = scanner.nextInt();
						if(choice2 == 2) {

				System.out.println("*** Thank you *** ");
							System.exit(0);
							break;
						}
						else if(choice2==1) {
							mainflag=false;
						}
						else {
							throw new BookException("Enter option 1 or 2");
						}
							
						
						}catch(InputMismatchException e) {
							System.out.println("Enter numbers only");
							
						}
						catch(BookException e) {
							System.out.println(e.getMessage());
						}
						}while(mainflag);
					break;

				case 3:

					boolean bookidflag = false;

					BookService service3 = new BookService();

					do {
						try {
							scanner = new Scanner(System.in);
							System.out.println("Enter the book id");

							List<BookBean> booklist = new ArrayList<BookBean>();
							int bookId = scanner.nextInt();
							bean.setBook_id(bookId);
							booklist = service3.searchBook(bookId);

							if (booklist != null) {

								Iterator<BookBean> i2 = booklist.iterator();

								if (i2.hasNext()) {
									System.out.println(i2.next());
									bookidflag = true;
								} else {
									System.out.println("enter existing book id");
								}

							}

						} catch (InputMismatchException e) {
							System.out.println("enter numbers only");

						} catch (BookException e) {
							System.err.println(e.getMessage());
						}

					} while (!bookidflag);
					scanner = new Scanner(System.in);
					String title = null;
					boolean titleflag = false;

					do {
						System.out.println("Enter the new name of the book");
						try {
							title = scanner.nextLine();
							service.validateTitle(title);
							titleflag = true;
							bean.setBook_title(title);
							break;
						} catch (BookException e) {
							System.err.println(e.getMessage());
						}
					} while (!titleflag);
					
					String author = null;
					boolean authorflag = false;
					do {
						System.out.println("Enter author name of the book");
						try {
							author = scanner.nextLine();
							service.validateAuthor(author);
							authorflag = true;
							bean.setAuthor(author);
							break;
						} catch (BookException e) {
							System.err.println(e.getMessage());
						}
					} while (!authorflag);
					
					String category = null;
					boolean categoryflag = false;
					do {
						System.out.println("Enter the category of the book");
						try {
							category = scanner.nextLine();
							service.vaildateCategory(category);
							categoryflag = true;
							bean.setCategory(category);

							break;
						} catch (BookException e) {
							System.err.println(e.getMessage());
						}
					} while (!categoryflag);

					float price;
					boolean priceflag = false;
					do {
						System.out.println("what is the price of the book");
						try {
							scanner = new Scanner(System.in);
							price = scanner.nextFloat();

							service.validatePrice(price);
							priceflag = true;

							bean.setPrice(price);
							break;
						}

						catch (InputMismatchException e) {
							System.err.println("Enter only digits");
						} catch (BookException e) {
							System.out.println(e.getMessage());
						}
					} while (!priceflag);

					scanner = new Scanner(System.in);
					String description = null;
					boolean descriptionflag = false;
					do {
						System.out.println("Enter the description");
						try {
							description = scanner.nextLine();
							service.validateDescription(description);
							descriptionflag = true;
							bean.setDescription(description);
							break;
						} catch (BookException e) {
							System.err.println(e.getMessage());
						}
					} while (!descriptionflag);
					boolean isbnflag = false;
					long isbn;
					do {
						System.out.println("Enter the ISBN");
						try {
							scanner = new Scanner(System.in);
							isbn = scanner.nextLong();
							service.validateISBN(isbn);
							isbnflag = true;

							bean.setIsbn(isbn);
							break;
						} catch (InputMismatchException e) {
							System.out.println("Enter digits only");

						} catch (BookException e) {
							System.err.println(e.getMessage());
						}
					} while (!isbnflag);
					String publishDate = null;
					boolean publishdateflag = false;
					do {
						System.out.println("Enter the publish date");
						try {
							publishDate = scanner.next();
							service.validatePublishdate(publishDate);
							publishdateflag = true;
							bean.setPublish_date(publishDate);
						} catch (BookException e) {
							System.err.println(e.getMessage());
						}
					} while (!publishdateflag);

					service.editBookDetails(bean);
					do {System.out.println("Do you wish to continue 1)yes \n 2)no");
					try {
					scanner=new Scanner(System.in);
					int choice2 = scanner.nextInt();
					if(choice2 == 2) {

			System.out.println("*** Thank you *** ");
						System.exit(0);
						break;
					}
					else if(choice2==1) {
						mainflag=false;
					}
					else {
						throw new BookException("Enter option 1 or 2");
					}
						
					
					}catch(InputMismatchException e) {
						System.out.println("Enter numbers only");
						
					}
					catch(BookException e) {
						System.out.println(e.getMessage());
					}
					}while(mainflag);
					break;

				case 4:
					/**  Getting BookId from the user to delete  **/
					int i3 = 0;
					do {
						System.out.println("Enter the book id");
						try {
							scanner = new Scanner(System.in);

							int Bookid = scanner.nextInt();
							bean.setBook_id(Bookid);
							List<BookBean> booklist = new ArrayList<BookBean>();

							booklist = service.searchBook(Bookid);

							if (booklist != null) {

								Iterator<BookBean> i2 = booklist.iterator();

								if (i2.hasNext()) {
									System.out.println(i2.next());
									int a = 0;
									do {
                                        try {
										System.out.println("Do you wish to continue deleting this book? \n 1)yes 2)no");
										scanner=new Scanner(System.in);
										a = scanner.nextInt();
										if (a == 1) {
											i3++;

										}
									}catch(InputMismatchException e) {
										System.out.println("Enter numbers only");
									}
									}
                                        while (a != 2 && a != 1);

								} else {
									System.out.println("Please enter existing bookId");
								}

							}

						} catch (InputMismatchException e) {
							System.out.println("Enter numbers only");

						}

						catch (BookException e) {
							System.err.println(e.getMessage());
						}
					} while (i3 == 0);
					int bookid = bean.getBook_id();
					int i = service.deleteBook(bookid);
					if (i == 1) {
						System.out.println("Book deleted successfully");
					} else {

						System.out.println("Could not delete the book");
					}
					
					do {System.out.println("Do you wish to continue 1)yes \n 2)no");
					try {
					scanner=new Scanner(System.in);
					int choice2 = scanner.nextInt();
					if(choice2 == 2) {

			System.out.println("*** Thank you *** ");
						System.exit(0);
						break;
					}
					else if(choice2==1) {
						mainflag=false;
					}
					else {
						throw new BookException("Enter option 1 or 2");
					}
						
					
					}catch(InputMismatchException e) {
						System.out.println("Enter numbers only");
						
					}
					catch(BookException e) {
						System.out.println(e.getMessage());
					}
					}while(mainflag);
					break;

				case 5:
					System.out.println("*** Thank you *** ");
					System.exit(0);
					break;

				default:

					System.out.println("input should be 1 to 5");
					break;
				}

			} catch (InputMismatchException e) {
				System.out.println("input numbers only");
			} 
		}
	}
	finally {
		scanner.close();
	}
}}

