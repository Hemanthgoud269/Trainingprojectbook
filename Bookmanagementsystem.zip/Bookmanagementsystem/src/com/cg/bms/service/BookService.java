package com.cg.bms.service;

import java.util.ArrayList;
import java.util.List;

import java.util.regex.Pattern;

import com.cg.bms.bean.BookBean;
import com.cg.bms.dao.BookDao;
import com.cg.bms.exceptions.BookException;


public class BookService implements IBookService {
	BookDao dao= new BookDao();
	BookBean bean= new BookBean();
	/*******************************************************************************************************
	 - Function Name	:	addBookDetails(BookBean bean)
	 - Input Parameters	:	BookBean bean
	 - Return Type		:	Integer
	 - Throws			:  	BookException
	 - Author			:	HEMANTH GOUD
	 - Creation Date	:	19/06/2019
	 - Description		:	Adding Book into the database table calls BookDao method addBookDetails(bean);
	 ********************************************************************************************************/
	@Override
	public int addBookDetails(BookBean bean) throws Exception {
		
		
		int bookId=dao.addBookDetails(bean);
		return bookId;
	}
	/*******************************************************************************************************
	 - Function Name	:   editBookDetails(BookBean bean)
	 - Input Parameters	:	bean
	 - Return Type		:	integer
	 - Throws			:  	BookException
	 - Author			:	HEMANTH GOUD
	 - Creation Date	:	20/06/2019
	 - Description		:	For updating of new details of the book, calls BookDao method addBookDetails(bean);
	 ********************************************************************************************************/
	@Override
	public int editBookDetails(BookBean bean) throws Exception {
		
		dao.addBookDetails(bean);
		
	return 0;
	}
	/*******************************************************************************************************
	 - Function Name	:   viewBookDetails()
	 - Input Parameters	:	
	 - Return Type		:	List
	 - Throws			:  	BookException
	 - Author			:	HEMANTH GOUD
	 - Creation Date	:	19/06/2019
	 - Description		:	For getting details of all the books in the database table, calls BookDao method viewBookDetails();
	 ********************************************************************************************************/
	@Override
	public List<BookBean> viewBookDetails() throws Exception {
		
		List<BookBean> books=new ArrayList<BookBean>();;
		
		books=dao.viewBookDetails();
		
		return books;
	}
	/*******************************************************************************************************
	 - Function Name	:   deleteBook(integer id)
	 - Input Parameters	:	BookId
	 - Return Type		:	integer
	 - Throws			:  	BookException
	 - Author			:	HEMANTH GOUD
	 - Creation Date	:	20/06/2019
	 - Description		:	For deleting book details from database, calls BookDao method deleteBook(int Id)
	 ********************************************************************************************************/
	@Override
	public int deleteBook(int Id) throws Exception {
	
	
		int i=dao.deleteBook(Id);
		return i;
	
	}
	/*******************************************************************************************************
	 - Function Name	:   searchBook(integer Id)
	 - Input Parameters	:	List
	 - Return Type		:	integer
	 - Throws			:  	BookException
	 - Author			:	HEMANTH GOUD
	 - Creation Date	:	21/06/2019
	 - Description		:	Validates the given bookId and calls BookDao method searchBook(integer id)
	 ********************************************************************************************************/
	@Override
	public List<BookBean> searchBook(int id) throws Exception {
		
		
		List<BookBean> books=new ArrayList<BookBean>();;
	if(id<9999) {
	books=dao.searchBook(id);
	}
		else
		{
			throw new BookException("Enter natural number with less than 4 digits");
		}
	return books;
		}

	/*******************************************************************************************************
	 - Function Name	:   validateTitle(String title)
	 - Input Parameters	:	title
	 - Return Type		:	void
	 - Throws			:  	BookException
	 - Author			:	HEMANTH GOUD
	 - Creation Date	:	22/06/2019
	 - Description		:	Validates given title with the specified pattern
	 ********************************************************************************************************/

	@Override
	public void validateTitle(String title) throws BookException {
	
		String titleRegEx = "[a-zA-Z\\s]{5,64}";
		if (!Pattern.matches(titleRegEx, title)) {
			throw new BookException("Enter alphabets with minimum of five characters");
		}
		
		
	}

	/*******************************************************************************************************
	 - Function Name	:   validateAuthor(String author)
	 - Input Parameters	:	author
	 - Return Type		:	void
	 - Throws			:  	BookException
	 - Author			:	HEMANTH GOUD
	 - Creation Date	:	22/06/2019
	 - Description		:	Validates given author name with the specified pattern
	 ********************************************************************************************************/
	@Override
	public void validateAuthor(String author) throws BookException {

		String authorRegEx = "[a-zA-Z\\s]{5,100}";
		if (!Pattern.matches(authorRegEx, author)) {
			throw new BookException("Enter alphabets with minimum of five characters");
		}
		
	}
	/*******************************************************************************************************
	 - Function Name	:   vaildateCategory(String category)
	 - Input Parameters	:	category
	 - Return Type		:	void
	 - Throws			:  	BookException
	 - Author			:	HEMANTH GOUD
	 - Creation Date	:	22/06/2019
	 - Description		:	Validates given category name with the specified pattern
	 ********************************************************************************************************/
	@Override
	public void vaildateCategory(String category) throws BookException {
		
		String categoryRegEx = "[a-zA-Z\\s]{2,20}";
		if (!Pattern.matches(categoryRegEx, category)) {
			throw new BookException("Enter alphabets with minimum of two characters");
		}
	}
	/*******************************************************************************************************
	 - Function Name	:   validatePrice(float price)
	 - Input Parameters	:	price
	 - Return Type		:	void
	 - Throws			:  	BookException
	 - Author			:	HEMANTH GOUD
	 - Creation Date	:	22/06/2019
	 - Description		:	Validates given price with the specified conditions
	 ********************************************************************************************************/
	@Override
	public void validatePrice(float price) throws BookException {
	
		
		if(price<10.00)
		{
			throw new BookException("price should not be less than 10rs");
		}
		if(price>50000.00)
		{
			throw new BookException("price should not be more than 50,000rs");
		}
		
	}
	/*******************************************************************************************************
	 - Function Name	:   validateISBN(long isbn)
	 - Input Parameters	:	isbn
	 - Return Type		:	void
	 - Throws			:  	BookException
	 - Author			:	HEMANTH GOUD
	 - Creation Date	:	22/06/2019
	 - Description		:	Validates given isbn with the specified conditions
	 ********************************************************************************************************/
	@Override
	public void validateISBN(long isbn) throws BookException {
		
		
		String patternRegEx="^[0-9]{10,15}$";
		if(!Pattern.matches(patternRegEx, Long.toString(isbn)))
		{
			throw new BookException("ISBN should have minimum of 10 and maximum of 15 digits");
		}
	}
	/*******************************************************************************************************
	 - Function Name	:   validatePublishdate(String publishdate) 
	 - Input Parameters	:	publishdate
	 - Return Type		:	void
	 - Throws			:  	BookException
	 - Author			:	HEMANTH GOUD
	 - Creation Date	:	22/06/2019
	 - Description		:	Validates given publishDate with the specific pattern
	 ********************************************************************************************************/
	@Override
	public void validatePublishdate(String publishdate) throws BookException {
		
		String dateRegEx = "^[0-3][0-9]/[0-3][0-9]/(?:[0-9][0-9])?[0-9][0-9]$";
		 
		if (!Pattern.matches(dateRegEx, publishdate)) {
			throw new BookException("plese follow the date format of dd/mm/yyyy");
		}
	}
	/*******************************************************************************************************
	 - Function Name	:   validateDescription(String description) 
	 - Input Parameters	:	description
	 - Return Type		:	void
	 - Throws			:  	BookException
	 - Author			:	HEMANTH GOUD
	 - Creation Date	:	22/06/2019
	 - Description		:	Validates given description with the specific pattern
	 ********************************************************************************************************/
	@Override
	public void validateDescription(String description) throws BookException {
		
		String nameRegEx = "[a-zA-Z\\s]{20,200}";
		if (!Pattern.matches(nameRegEx, description)) {
			throw new BookException("Enter alphabets with munimum of twenty characters");
		}
		
	}
	/*******************************************************************************************************
	 - Function Name	:   checkEmailPattern(String email) 
	 - Input Parameters	:	email
	 - Return Type		:	void
	 - Throws			:  	BookException
	 - Author			:	HEMANTH GOUD
	 - Creation Date	:	22/06/2019
	 - Description		:	Checks the pattern of the given email
	 ********************************************************************************************************/
	@Override
	public void checkEmailPattern(String email) throws BookException {
		
	
		String emailpattern = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
		
		if (!Pattern.matches(emailpattern, email)) {
			
			throw new BookException("Enter the email in correct pattern");
		}
		
		
		
	}
	/*******************************************************************************************************
	 - Function Name	:   checkPasswordPattern(String adminpassword) 
	 - Input Parameters	:	adminpassword
	 - Return Type		:	void
	 - Throws			:  	BookException
	 - Author			:	HEMANTH GOUD
	 - Creation Date	:	22/06/2019
	 - Description		:	Checks the pattern of the given password
	 ********************************************************************************************************/

	@Override
	public void checkPasswordPattern(String adminpassword) throws BookException {
		
		
		System.out.println(adminpassword);
		String passwordRegEx="^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{3,16}$";
		if (!Pattern.matches(passwordRegEx, adminpassword)) {
			
			throw new BookException(" enter the password pattern correctly");
		}
		
	}
	/*******************************************************************************************************
	 - Function Name	:   checkPasswordPattern(String adminpassword) 
	 - Input Parameters	:	adminpassword
	 - Return Type		:	void
	 - Throws			:  	BookException
	 - Author			:	HEMANTH GOUD
	 - Creation Date	:	22/06/2019
	 - Description		:	Checks the pattern of the given password
	 ********************************************************************************************************/
	@Override
	public boolean adminLogin(BookBean bean) throws Exception {
		
		boolean adminloginflag=false;
		adminloginflag=dao.adminLogin(bean);
		return adminloginflag;
	}
	/*******************************************************************************************************
	 - Function Name	:   adminEmail(String email)
	 - Input Parameters	:	email
	 - Return Type		:	void
	 - Throws			:  	BookException
	 - Author			:	HEMANTH GOUD
	 - Creation Date	:	22/06/2019
	 - Description		:	Checks whether the given emails exists or not by calling BookDao method adminEmail(email)
	 ********************************************************************************************************/
	@Override
	public boolean adminEmail(String email) throws Exception {
	
		boolean adminemailflag=false;
		adminemailflag=dao.adminEmail(email);
		return adminemailflag;
	}

	
	}

