package com.cg.bms.service;

import java.util.List;

import com.cg.bms.bean.BookBean;
import com.cg.bms.exceptions.BookException;

public interface IBookService {
public int addBookDetails(BookBean bean) throws Exception;
public int editBookDetails(BookBean bean) throws Exception;
public List<BookBean> viewBookDetails() throws Exception;
public int deleteBook(int Id) throws Exception;
public List<BookBean> searchBook(int Id) throws Exception;
public void validateTitle(String title) throws BookException;

public void validateAuthor(String author) throws BookException;
public void vaildateCategory(String category) throws BookException;
public void validatePrice(float price) throws BookException;
public void validateISBN(long isbn) throws BookException;
public void validatePublishdate(String publishdate) throws BookException;
public void validateDescription(String description) throws BookException;
public void checkEmailPattern(String email) throws BookException;
public void checkPasswordPattern(String adminpassword) throws BookException;
public boolean adminLogin(BookBean bean) throws Exception;
public boolean adminEmail(String email) throws Exception;
}
